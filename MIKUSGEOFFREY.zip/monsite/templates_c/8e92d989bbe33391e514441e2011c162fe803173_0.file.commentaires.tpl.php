<?php
/* Smarty version 3.1.30, created on 2016-12-15 11:40:03
  from "C:\UwAmp\www\monsite\templates\commentaires.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_585281135d93c9_63814373',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8e92d989bbe33391e514441e2011c162fe803173' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\commentaires.tpl',
      1 => 1481801997,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_585281135d93c9_63814373 (Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_articles']->value, 'tabs');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tabs']->value) {
?> 

    <h2> <?php echo $_smarty_tpl->tpl_vars['tabs']->value['titre'];?>
 </h2>

    <img src="img/<?php echo $_smarty_tpl->tpl_vars['tabs']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['tabs']->value['titre'];?>
" width="160px" class="img-rounded"/>

    <h6><p style="text-align: justify;"><?php echo $_smarty_tpl->tpl_vars['tabs']->value['texte'];?>
</p></h6>
    <p><em><u> Publié le :<?php echo $_smarty_tpl->tpl_vars['tabs']->value['date_fr'];?>
 </u></em></p>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

         Commentaire(s) :  <span class="badge">  <?php echo $_smarty_tpl->tpl_vars['nbCom']->value['NbComm'];?>
</span>   


<?php echo '<script'; ?>
 language="javascript" type="text/javascript">
//Si un champ de formulaire est vide, cette fonction avertit à l'aide d'un message, 
//et renvoie false, pour empêcher la soumission du formulaire
    function validateForm() {
        var x = document.forms["formCom"]["pseudoCom"].value;
        if (x == "") {
            alert("Le pseudo est vide");
            return false;
        }
        var y = document.forms["formCom"]["emailCom"].value;
        if (y == "") {
            alert("L'email est vide");
            return false;
        }
        var z = document.forms["formCom"]["texteCom"].value;
        if (z == "") {
            alert("Le texte est vide");
            return false;
        }
    }
<?php echo '</script'; ?>
>
<h3> Votre Commentaire</h3>



<form  name="formCom" method="post" action="commentaires.php" onsubmit="return validateForm()"  >
    <div class="clearfix">
        <label for="pseudo">Pseudo</label>
        <input type="text" name="pseudoCom" id="pseudoCom"/></div>
    <br>
    <div class="email">
        <label for="email">Email</label>
        <input type="email" name="emailCom" id="emailCom" /></div>
    <br>
    <div class="form-group">
        <label for="texteCom">Texte </label>
        <div class="textarea">
            <textarea class="form-control" rows="3" name="texteCom" id="texteCom" value = "" ></textarea>
        </div>
    </div>  
    <br>
    <div class="form-actions">
        <input type="submit" name="inserer" value="insertion" class="btn btn-large btn-primary" />
    </div>  
    
    <input type="hidden" name ="articles_id" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"/>

</form>	
    
    <h2> Les Commentaires</h2>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_coms']->value, 'coms');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['coms']->value) {
?> 

    <h4><span class="glyphicon glyphicon-user"></span> <?php echo $_smarty_tpl->tpl_vars['coms']->value['pseudoCom'];?>
 </h4>
    <h5><span class="glyphicon glyphicon-envelope"></span>  <?php echo $_smarty_tpl->tpl_vars['coms']->value['emailCom'];?>
 </h5>
    <h4><pre><?php echo $_smarty_tpl->tpl_vars['coms']->value['texteCom'];?>
 </pre> </h4>


<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<br>

<?php }
}
