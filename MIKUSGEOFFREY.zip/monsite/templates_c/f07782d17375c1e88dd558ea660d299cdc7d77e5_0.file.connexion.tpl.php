<?php
/* Smarty version 3.1.30, created on 2016-12-10 16:15:14
  from "C:\UwAmp\www\monsite\templates\connexion.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_584c2a127f2a85_20140518',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f07782d17375c1e88dd558ea660d299cdc7d77e5' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\connexion.tpl',
      1 => 1481386277,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_584c2a127f2a85_20140518 (Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="span8">                                 
    
    <form action="connexion.php" method="post" enctype="multipart/form-data" id="form_article" name="connexion">  <!-- Appel un formulaire pour créer se connecter-->

        <div class="clearfix">
            <label for="email">Email</label>
            <div class="email"><input type="email" name="email" id="email" value="Votre Email"></div>
        </div>

        <div class="clearfix">
            <label for="mdp">Mot De Passe</label>
            <div class="input"><input type="password" name="mdp" id="mdp" value="Votre Passe"></div>
        </div>

        <div class="clearfix">
            <input type="submit" name="envoyer" value="Envoyer" class="btn btn-large btn-primary"></div>

    </form>

</div><?php }
}
