<?php
/* Smarty version 3.1.30, created on 2016-12-10 16:15:45
  from "C:\UwAmp\www\monsite\templates\register.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_584c2a31be6d35_29909269',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f12bf8a095f205936757403106aa961462bd9068' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\register.tpl',
      1 => 1481386493,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_584c2a31be6d35_29909269 (Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="span8">
<h2> Inscription</h2>
<h4> Vos coordonnées : </h4>     
<div>
    <form action="register.php" method="post" enctype="multipart/form-data" id="form_inscription" name="form_inscription">
        <div class="clearfix">
            <label for="nom">Nom : </label>
            <div class="input">
                <input type="text" name="nom" id="nom" value=""/>
            </div>
            <div class="clearfix">
                <label for="prenom">Prénom : </label>
                <div class="input">
                    <input type="text" name="prenom" id="prenom" value=""/>
                </div>
            </div> 
            <div class="clearfix">
                <label for="email">Email : </label>
                <div class="input">
                    <input type="email" name="email" id="email" value="" required="required"/>
                </div>
            </div>    
            <div class="clearfix">
                <label for="passe">Mot de passe : </label>
                <div class="input">
                    <input type="password" name="mdp" id="mdp" value="" required="required"/>
                </div>
            </div>   
            

            <div class="form-actions">
                <input type="submit" name="register" value="S'inscrire" class="btn btn-large btn-primary" />
            </div>   
            </div>

    </form>
</div>
        </div>

<?php }
}
