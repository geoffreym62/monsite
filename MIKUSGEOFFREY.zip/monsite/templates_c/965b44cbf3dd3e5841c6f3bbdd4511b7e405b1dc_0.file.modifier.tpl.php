<?php
/* Smarty version 3.1.30, created on 2016-12-13 21:51:59
  from "C:\UwAmp\www\monsite\templates\modifier.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58506d7fa66827_84582733',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '965b44cbf3dd3e5841c6f3bbdd4511b7e405b1dc' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\modifier.tpl',
      1 => 1481665706,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58506d7fa66827_84582733 (Smarty_Internal_Template $_smarty_tpl) {
?>


<form action="modifier.php" method="post" enctype="multipart/form-data" id="form_modif" name="form_modif">
        <input type="hidden" name="id_encours" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
        <div class="clearfix">
            <label for="titre">Titre : </label>
            <div class="input">
                <input type="text" name="titre" id="titre" value="<?php echo $_smarty_tpl->tpl_vars['upTitre']->value;?>
"/>
            </div>
        </div>    
        <div class="clearfix">
            <label for="texte">Texte : </label>
            <div class="textarea">
                <textarea name="texte" id="texte" value = ""><?php echo $_smarty_tpl->tpl_vars['upTexte']->value;?>
</textarea>
            </div>
        </div>  
        <div class="clearfix">
            <label for="publie">Publié : </label>
            <div class="input">
                <input type="checkbox" name="publie" id="publie" value="<?php echo $_smarty_tpl->tpl_vars['upPublie']->value;?>
" checked  />
            </div>
        </div> 
        <div class="form-actions">
            <input type="submit" name="modifier" id="modifier" value="modifier" class="btn btn-large btn-primary" />
        </div>   
    </form><?php }
}
