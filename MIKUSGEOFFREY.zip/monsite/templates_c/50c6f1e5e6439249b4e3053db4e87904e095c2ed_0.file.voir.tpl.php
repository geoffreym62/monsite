<?php
/* Smarty version 3.1.30, created on 2016-12-10 12:28:51
  from "C:\UwAmp\www\monsite\templates\voir.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_584bf50387cbd3_09144315',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '50c6f1e5e6439249b4e3053db4e87904e095c2ed' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\voir.tpl',
      1 => 1481372853,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_584bf50387cbd3_09144315 (Smarty_Internal_Template $_smarty_tpl) {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_articles']->value, 'tabs');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tabs']->value) {
?> 
      
    <h2> <?php echo $_smarty_tpl->tpl_vars['tabs']->value['titre'];?>
 </h2>
   
    <img src="img/<?php echo $_smarty_tpl->tpl_vars['tabs']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['tabs']->value['titre'];?>
" width="160px" class="img-rounded"/>
     
    <h6><p style="text-align: justify;"><?php echo $_smarty_tpl->tpl_vars['tabs']->value['texte'];?>
</p></h6>
    <p><em><u> Publié le :<?php echo $_smarty_tpl->tpl_vars['tabs']->value['date_fr'];?>
 </u></em></p>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


<h2> Les Commentaires</h2>
        
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_coms']->value, 'coms');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['coms']->value) {
?> 
      
    <h4> <?php echo $_smarty_tpl->tpl_vars['coms']->value['pseudoCom'];?>
 </h4>
     <h5> <?php echo $_smarty_tpl->tpl_vars['coms']->value['emailCom'];?>
 </h5>
      <h4> <?php echo $_smarty_tpl->tpl_vars['coms']->value['texteCom'];?>
 </h4>
   

    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

    
    <?php echo '<script'; ?>
 language="javascript" type="text/javascript">
        function controle() {
            // vérification javascript des champs obligatoires non vides 	
            var emailCom = document.getElementById("emailCom").value;
            var texteCom = document.getElementById("texteCom").value;

            if (emailCom === "") {
                alert(" Le champ Email du commentaire est vide ");
                document.formCom.emailCom.focus();
                return false;
            }

            if (texteCom === "") {
                alert(" Le champ Texte du commentaire est vide ");
                document.formCom.texteCom.focus();
                return false;
            }

            //if(titreCom && texteCom ){ 
            document.formCom.method = "POST";
            document.formCom.action = "voir.php";

            //soumission du formulaire
            document.getElementById("formCom").submit();
        }
    <?php echo '</script'; ?>
>
    <h3> Votre Commentaire</h3>

    <form  name="formCom" method="post" action="commentaires.php"  >
        <div class="clearfix">
        <label for="pseudo">Pseudo</label>
        <input type="text" name="pseudoCom" id="pseudoCom"value="Votre Pseudo"/></div>
        <br>
        <div class="email">
        <label for="email">Email</label>
        <input type="email" name="emailCom" id="emailCom" value="Votre Email"/></div>
        <br>
       <div class="form-group">
        <label for="texteCom">Texte </label>
        <div class="textarea">
         <textarea class="form-control" rows="3" name="texteCom" id="texteCom" value = "" ></textarea>
         </div>
        </div>  
        <br>
        <div class="form-actions">
            <input type="submit" name="inserer" value="insertion" class="btn btn-large btn-primary" />
        </div>  
        <input type="hidden" name ="articles_id" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"/>

    </form>	
        <br><?php }
}
