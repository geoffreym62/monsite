<?php
/* Smarty version 3.1.30, created on 2016-12-14 12:15:17
  from "C:\UwAmp\www\monsite\templates\recherche.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_585137d594cfd6_31752530',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fdbb7fd91ed82640f9dce26989554c565465fb80' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\recherche.tpl',
      1 => 1481387064,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_585137d594cfd6_31752530 (Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_recherche']->value, 'tableau');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tableau']->value) {
?> 
    
    <h2> <?php echo $_smarty_tpl->tpl_vars['tableau']->value['titre'];?>
 </h2>
    <img src="img/<?php echo $_smarty_tpl->tpl_vars['tableau']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['tableau']->value['titre'];?>
" width="160px" class="img-rounded"/>

    <h6><p style="text-align: justify;"><?php echo $_smarty_tpl->tpl_vars['tableau']->value['texte'];?>
</p></h6>
    <p><em><u> Publié le :<?php echo $_smarty_tpl->tpl_vars['tableau']->value['date_fr'];?>
 </u></em></p>

<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
}
}
