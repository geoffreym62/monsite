<?php
/* Smarty version 3.1.30, created on 2016-11-21 12:31:01
  from "C:\wamp64\www\monsite\templates\smarty.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5832e905b92577_13739422',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f3cef7edc0a95a015edffdfb60d6bd400699e8ae' => 
    array (
      0 => 'C:\\wamp64\\www\\monsite\\templates\\smarty.tpl',
      1 => 1479731433,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5832e905b92577_13739422 (Smarty_Internal_Template $_smarty_tpl) {
?>
<p>Bonjour je m'appelle <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</p><?php }
}
