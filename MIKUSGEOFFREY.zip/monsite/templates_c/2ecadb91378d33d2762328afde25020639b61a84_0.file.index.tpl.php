<?php
/* Smarty version 3.1.30, created on 2016-12-15 11:37:04
  from "C:\UwAmp\www\monsite\templates\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_585280607f5af7_97458499',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2ecadb91378d33d2762328afde25020639b61a84' => 
    array (
      0 => 'C:\\UwAmp\\www\\monsite\\templates\\index.tpl',
      1 => 1481801402,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_585280607f5af7_97458499 (Smarty_Internal_Template $_smarty_tpl) {
?>



<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_articles']->value, 'tabs');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tabs']->value) {
?> 
      
    <h2> <?php echo $_smarty_tpl->tpl_vars['tabs']->value['titre'];?>
 </h2>
   
    <img src="img/<?php echo $_smarty_tpl->tpl_vars['tabs']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['tabs']->value['titre'];?>
" width="160px" class="img-rounded"/>
     
    <h6><p style="text-align: justify;"><?php echo $_smarty_tpl->tpl_vars['tabs']->value['texte'];?>
</p></h6>
    <p><em><u> Publié le :<?php echo $_smarty_tpl->tpl_vars['tabs']->value['date_fr'];?>
 </u></em></p>
    
    
    <a href='commentaires.php?id=<?php echo $_smarty_tpl->tpl_vars['tabs']->value['id'];?>
'><input type="submit"name ="voir" value="Commentaires" class="btn btn-primary active"></a>
          
    <div style="<?php if ($_smarty_tpl->tpl_vars['sid']->value == '') {?>display:none;<?php }?> ">
        <br>
        
    <a href='modifier.php?id=<?php echo $_smarty_tpl->tpl_vars['tabs']->value['id'];?>
'><input type="submit"name ="modifier" value="Modifier" class="btn btn-sm btn-success"></a>
    <a href='article.php?supprime=<?php echo $_smarty_tpl->tpl_vars['tabs']->value['id'];?>
'><input type="submit"name ="supprime" value="Supprimer" class="btn btn-sm btn-danger"></a>
 </div> 
    
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>



<br>


        <div class="pagination">
            <ul>
                
                <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['nbPages']->value+1 - (1) : 1-($_smarty_tpl->tpl_vars['nbPages']->value)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 1, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration == 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration == $_smarty_tpl->tpl_vars['i']->total;?>
                    
                    <li <?php if ($_smarty_tpl->tpl_vars['i']->value == $_smarty_tpl->tpl_vars['pageCourante']->value) {?> class="active" <?php }?>><a href="index.php?p=<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['i']->value;?>
</a></li>
                    <?php }
}
?>

            </ul>
        </div>

    
<?php }
}
